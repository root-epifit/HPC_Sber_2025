#include <pybind11/pybind11.h>
#include <pybind11/numpy.h>
#include "matrix_operations.h"

namespace py = pybind11;

void pybind11_matrix_multiply(py::array_t<double> a,
                             py::array_t<double> b,
                             py::array_t<double> c,
                             int n) {


    double *a_ptr = static_cast<double*>(a.request().ptr);
    double *b_ptr = static_cast<double*>(b.request().ptr);
    double *c_ptr = static_cast<double*>(c.request().ptr);

    matrix_multiply(a_ptr, b_ptr, c_ptr, n);
}


PYBIND11_MODULE(matrix, m) {
    m.def("pybind11_matrix_multiply", &pybind11_matrix_multiply, "Multiply two matrices");
}
