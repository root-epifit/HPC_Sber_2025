#ifndef MATRIX_OPERATIONS_H
#define MATRIX_OPERATIONS_H

void matrix_multiply(double* A, double* B, double* C, int N);

#endif
